#include <Arduino.h>
#include "encoder.h"
#include "digital_out.h"

int main()
{
  Digital_out led(5); //Built-in LED
  Encoder encoder(4, 5); //c1: D2, c2: D3

  led.init();
  encoder.init();

  Serial.begin(9600);

  while (1) {
    
    
    bool c1_hi = encoder.is_C1_hi();
    bool c2_hi = encoder.is_C2_hi();


    if (c1_hi && !c2_hi) {
      encoder.updateCounter(true);
      Serial.println(encoder.getPosition());
    } else if (!c1_hi && c2_hi) {
      encoder.updateCounter(false);
      Serial.println(encoder.getPosition());
    }
    

    while (c1_hi || c2_hi) {
      c1_hi = encoder.is_C1_hi();
      c2_hi = encoder.is_C2_hi();
      led.set_hi();
    }
    
    _delay_us(1000);  //sampling rate of 1 ms
    led.set_lo();
  }

  return 0;
}